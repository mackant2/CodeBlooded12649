package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

@Autonomous

public class RedMainAuto extends MainAuto { 

    public RedMainAuto(){
        super.Alliance = false;
}

}