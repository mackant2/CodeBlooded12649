package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

@Autonomous

public class BlueMainAuto extends MainAuto { 

    public BlueMainAuto(){
        super.Alliance = true;
}

}