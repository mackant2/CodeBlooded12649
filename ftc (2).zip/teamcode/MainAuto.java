package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.hardware.Servo;
import java.util.Locale;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DistanceSensor;


import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;

@Autonomous(name="MainAuto.java", group="chad")
public class MainAuto extends LinearOpMode {
    //
    Servo   servo;
    
     BNO055IMU imu;

    Orientation angles;
    Acceleration gravity;
    
    DcMotor frontleft;
    DcMotor frontright;
    DcMotor backleft;
    DcMotor backright;
    DcMotor Duckspinner;
    DcMotor Arm;
    DcMotor Outtake;
    private DistanceSensor sensorRange;
    Rev2mDistanceSensor sensorTimeOfFlight = (Rev2mDistanceSensor)sensorRange;


    //28 * 20 / (2ppi * 4.125)
    Double width = 16.0; //inches
    Integer cpr = 28; //counts per rotation
    Integer gearratio = 40;
    Double diameter = 4.125;
    Double cpi = (cpr * gearratio)/(Math.PI * diameter); //counts per inch, 28cpr * gear ratio / (2 * pi * diameter (in inches, in the center))
    Double bias = 0.8;//default 0.8
    Double meccyBias = 0.9;//change to adjust only strafing movement
    //
    Double conversion = cpi * bias;
    Boolean exit = false;
    static Boolean Red = false;
    static Boolean Blue = true;
    static Boolean Alliance;
    
    double duckSpinnerSpeed;
    double strafingDistance;
    
    double TMlevel = 3;

    double ClawPosition = 1;
   
    public void runOpMode(){
        //
        
         BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.calibrationDataFile = "BNO055IMUCalibration.json"; // see the calibration sample opmode
        parameters.loggingEnabled      = true;
        parameters.loggingTag          = "IMU";
        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();

         imu = hardwareMap.get(BNO055IMU.class, "imu");
        imu.initialize(parameters);
        
      //  initGyro();
         //sensor_color_REV_ColorRangeSensor = hardwareMap.get(ColorSensor.class, "sensor_color");
      // sensor_color_REV_ColorSensorV3 = hardwareMap.get(ColorSensor.class, "sensor_v3");
        //
        sensorRange = hardwareMap.get(DistanceSensor.class, "sensor_range");
        frontleft = hardwareMap.dcMotor.get("left_front");
        frontright = hardwareMap.dcMotor.get("right_front");
        backleft = hardwareMap.dcMotor.get("left_back");
        backright = hardwareMap.dcMotor.get("right_back");
        Duckspinner = hardwareMap.dcMotor.get("Duckspinner");
        Arm = hardwareMap.dcMotor.get("Arm");
        servo = hardwareMap.get(Servo.class, "Claw");
        Outtake = hardwareMap.dcMotor.get("Outtake");
        frontright.setDirection(DcMotorSimple.Direction.REVERSE);
        backright.setDirection(DcMotorSimple.Direction.REVERSE);
        
        backleft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontleft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backright.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontright.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        
        
        //
        waitForStartify();
        //
        
      //  imu.startAccelerationIntegration(new Position(), new Velocity(), 1000);
        
    //    angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        
        //telemetry.addData("heading", angles.firstAngle);
        //telemetry.update();
        
        
        
        
       
        
        if (TMlevel == 3){
         Arm.setTargetPosition(Arm.getCurrentPosition() + -1800); 
        }
     
     
        if (TMlevel == 2){
        Arm.setTargetPosition(Arm.getCurrentPosition() + -800);    
        }
           
        if (TMlevel == 1){    
         Arm.setTargetPosition(Arm.getCurrentPosition() + -400); 
        }
          Arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Arm.setPower(1);
            
          if (Alliance == Red){
            strafeToPosition(25, .3);
            sleep(1000);
        }
        else {
            strafeToPosition(-25, .3);
            sleep(1000);
        }
            
            while (Arm.isBusy())
          //  sleep(1000);
          
          Outtake.setPower(-1);
          sleep(2000);
          Outtake.setPower(0);
          
          if (TMlevel == 3);{
           Arm.setTargetPosition(Arm.getCurrentPosition() + 1300);
          }
          
           if (TMlevel == 2){
        Arm.setTargetPosition(Arm.getCurrentPosition() + 800);    
        }
           
        if (TMlevel == 1){    
         Arm.setTargetPosition(Arm.getCurrentPosition() + 400); 
        }
        
        if (Alliance == Red){
            strafeToPosition(-6, .4);
        }
        
        else {
        strafeToPosition(6, .4);
        }
        
            Arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
           Arm.setPower(1);
           
        if (Alliance == Red){
            strafeToPosition(-17, .4);
        }
        
        else {
        strafeToPosition(17, .4);
        }
        
        
        sleep(500);
        moveToPosition(16, 0.2);
     sleep(500);
        moveToPosition(.5, 0.1);
        
        Duckspinner.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        for(int i = 1; i <= 100;i += 1)   
        {
            duckSpinnerSpeed = 0.8;
            if (Alliance == Red)
            {
                 duckSpinnerSpeed *= -1;
            }
            Duckspinner.setPower(duckSpinnerSpeed * i / 100);
            sleep(5);
        }
    sleep(4000);
    Duckspinner.setPower(0);
    
   // if (Alliance == Red){
     //   strafingDistance *= -1;
    //}
    
    //sleep(1000);
    
    moveToPosition(-7, .3);
    
    if (Alliance == Red)
    {
            strafeToPosition(-4, .3);
    }
    
    else 
    
            strafeToPosition(4, .3);
            
            
   //ollie moveToPosition(-70.2, .5);
    
     moveWithWatch(-40, 0.4);
   
   
    int i = 0  ;
    while (sensorRange.getDistance(DistanceUnit.INCH)<10)
    {
        i = i + 1;
        if (i > 3)
            break; 
        if (Alliance == Red)
            strafeToPosition(5, .3);
            
        else
            strafeToPosition(-6, .3);
          
    }
    if (Alliance == Red && i > 0)
            strafeToPosition(5, .3);

    
        moveToPosition(-70, .6);
    }
    
    /*
    This function's purpose is simply to drive forward or backward.
    To drive backward, simply make the inches input negative.
     */
    
    public void moveToPosition(double inches, double speed){
        //
        int move = (int)(Math.round(inches*conversion));
//
        backleft.setTargetPosition(backleft.getCurrentPosition() + move);
        frontleft.setTargetPosition(frontleft.getCurrentPosition() + move);
        backright.setTargetPosition(backright.getCurrentPosition() + move);
        frontright.setTargetPosition(frontright.getCurrentPosition() + move);
        //
        frontleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //
                
        //frontleft.setPower(speed);
        //backleft.setPower(speed);
        //frontright.setPower(speed);
        //backright.setPower(speed);
        //
        
        double rotSpeed;
        
        while (frontleft.isBusy() && frontright.isBusy() && backleft.isBusy() && backright.isBusy())
        {    
            angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            rotSpeed =  (angles.firstAngle - 0) * .05;
  
  
            if (move < 0) 
                rotSpeed *= -1;
  
            frontleft.setPower(speed-rotSpeed);
            backleft.setPower(speed-rotSpeed);
            frontright.setPower(speed+rotSpeed);
            backright.setPower(speed+rotSpeed);
            
            // if it starts spinning change symbols from + to -.  
            telemetry.addData("frontleft", frontleft.getCurrentPosition());
            telemetry.addData("backleft", backleft.getCurrentPosition());
            telemetry.addData("frontright", frontright.getCurrentPosition());
            telemetry.addData("backright", backright.getCurrentPosition());
            telemetry.addData("heading", angles.firstAngle);
            telemetry.addData("range", String.format("%.01f in", sensorRange.getDistance(DistanceUnit.INCH)));
            telemetry.update();
            
            if (exit){
                frontright.setPower(0);
                frontleft.setPower(0);
                backright.setPower(0);
                backleft.setPower(0);
                return;
            }
        }
        frontright.setPower(0);
        frontleft.setPower(0);
        backright.setPower(0);
        backleft.setPower(0);
        return;
    }
    //
    /*
    This function uses the Expansion Hub IMU Integrated Gyro to turn a precise number of degrees (+/- 5).
    Degrees should always be positive, make speedDirection negative to turn left.
     */
    public void turnWithGyro(double degrees, double speedDirection){
        //<editor-fold desc="Initialize">
        angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        double yaw = -angles.firstAngle;//make this negative
        telemetry.addData("Speed Direction", speedDirection);
        telemetry.addData("Yaw", yaw);
        telemetry.update();
        //
        telemetry.addData("stuff", speedDirection);
        telemetry.update();
        //
        double first;
        double second;
        //</editor-fold>
        //
        if (speedDirection > 0){//set target positions
            //<editor-fold desc="turn right">
            if (degrees > 10){
                first = (degrees - 10) + devertify(yaw);
                second = degrees + devertify(yaw);
            }else{
                first = devertify(yaw);
                second = degrees + devertify(yaw);
            }
            //</editor-fold>
        }else{
            //<editor-fold desc="turn left">
            if (degrees > 10){
                first = devertify(-(degrees - 10) + devertify(yaw));
                second = devertify(-degrees + devertify(yaw));
            }else{
                first = devertify(yaw);
                second = devertify(-degrees + devertify(yaw));
            }
            //
            //</editor-fold>
        }
        //
        //<editor-fold desc="Go to position">
        Double firsta = convertify(first - 5);//175
        Double firstb = convertify(first + 5);//-175
        //
        turnWithEncoder(speedDirection);
        //
        if (Math.abs(firsta - firstb) < 11) {
            while (!(firsta < yaw && yaw < firstb) && opModeIsActive()) {//within range?
                angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
                gravity = imu.getGravity();
                yaw = -angles.firstAngle;
                telemetry.addData("Position", yaw);
                telemetry.addData("first before", first);
                telemetry.addData("first after", convertify(first));
                telemetry.update();
            }
        }else{
            //
            while (!((firsta < yaw && yaw < 180) || (-180 < yaw && yaw < firstb)) && opModeIsActive()) {//within range?
                angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
                gravity = imu.getGravity();
                yaw = -angles.firstAngle;
                telemetry.addData("Position", yaw);
                telemetry.addData("first before", first);
                telemetry.addData("first after", convertify(first));
                telemetry.update();
            }
        }
        //
        Double seconda = convertify(second - 5);//175
        Double secondb = convertify(second + 5);//-175
        //
        turnWithEncoder(speedDirection / 3);
        //
        if (Math.abs(seconda - secondb) < 11) {
            while (!(seconda < yaw && yaw < secondb) && opModeIsActive()) {//within range?
                angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
                gravity = imu.getGravity();
                yaw = -angles.firstAngle;
                telemetry.addData("Position", yaw);
                telemetry.addData("second before", second);
                telemetry.addData("second after", convertify(second));
                telemetry.update();
            }
            while (!((seconda < yaw && yaw < 180) || (-180 < yaw && yaw < secondb)) && opModeIsActive()) {//within range?
                angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
                gravity = imu.getGravity();
                yaw = -angles.firstAngle;
                telemetry.addData("Position", yaw);
                telemetry.addData("second before", second);
                telemetry.addData("second after", convertify(second));
                telemetry.update();
            }
            frontleft.setPower(0);
            frontright.setPower(0);
            backleft.setPower(0);
            backright.setPower(0);
        }
        //</editor-fold>
        //
        frontleft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontright.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backleft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backright.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    }
    //
    /*
    This function uses the encoders to strafe left or right.
    Negative input for inches results in left strafing.
     */
    public void strafeToPosition(double inches, double speed){
        //
        int move = (int)(Math.round(inches * cpi * meccyBias));
        //
        backleft.setTargetPosition(backleft.getCurrentPosition() - move);
        frontleft.setTargetPosition(frontleft.getCurrentPosition() + move);
        backright.setTargetPosition(backright.getCurrentPosition() + move);
        frontright.setTargetPosition(frontright.getCurrentPosition() - move);
        //
        frontleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //
        //frontleft.setPower(speed);
        //backleft.setPower(speed);
        //frontright.setPower(speed);
        //backright.setPower(speed);
        //
        double rotSpeed;
        
        while (frontleft.isBusy() && frontright.isBusy() && backleft.isBusy() && backright.isBusy() )
        {
            angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            rotSpeed =  (angles.firstAngle - 0) * .05;
            
            if (move < 0) 
                rotSpeed *= -1;
  
            frontleft.setPower(speed-rotSpeed);
            backleft.setPower(speed+rotSpeed);
            frontright.setPower(speed-rotSpeed);
            backright.setPower(speed+rotSpeed);
       
            telemetry.addData("hello", 1);
            telemetry.addData("speed", speed);
            telemetry.addData("rotspeed", rotSpeed);
            telemetry.addData("move", move);
            telemetry.update();
        
       
        }
        frontright.setPower(0);
        frontleft.setPower(0);
        backright.setPower(0);
        backleft.setPower(0);
        return;
    }
    /*
    A tradition within the Thunder Pengwins code, we always start programs with waitForStartify,
    our way of adding personality to our programs.
     */
    public void waitForStartify(){
        waitForStart();
    }
    //
    /*
    These functions are used in the turnWithGyro function to ensure inputs
    are interpreted properly.
     */
    public double devertify(double degrees){
        if (degrees < 0){
            degrees = degrees + 360;
        }
        return degrees;
    }
    public double convertify(double degrees){
        if (degrees > 179){
            degrees = -(360 - degrees);
        } else if(degrees < -180){
            degrees = 360 + degrees;
        } else if(degrees > 360){
            degrees = degrees - 360;
        }
        return degrees;
    }
    //
    /*
    This function is called at the beginning of the program to activate
    the IMU Integrated Gyro.
     */
    public void initGyro(){
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        //parameters.calibrationDataFile = "GyroCal.json"; // see the calibration sample opmode
        parameters.loggingEnabled      = true;
        parameters.loggingTag          = "IMU";
        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();
        //
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        imu.initialize(parameters);
       
        
    }
    //
    /*
    This function is used in the turnWithGyro function to set the
    encoder mode and turn.
     */
    public void turnWithEncoder(double input){
        frontleft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backleft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        frontright.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backright.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        //
        frontleft.setPower(input);
        backleft.setPower(input);
        frontright.setPower(-input);
        backright.setPower(-input);
    }

    
      public void moveWithWatch(double inches, double speed){
        //
        int move = (int)(Math.round(inches*conversion));
        //
        backleft.setTargetPosition(backleft.getCurrentPosition() + move);
        frontleft.setTargetPosition(frontleft.getCurrentPosition() + move);
        backright.setTargetPosition(backright.getCurrentPosition() + move);
        frontright.setTargetPosition(frontright.getCurrentPosition() + move);
        //
        frontleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backleft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backright.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //
        frontleft.setPower(speed);
        backleft.setPower(speed);
        frontright.setPower(speed);
        backright.setPower(speed);
        //
        double rotSpeed;
        
        while (frontleft.isBusy() && frontright.isBusy() && backleft.isBusy() && backright.isBusy() &&
            sensorRange.getDistance(DistanceUnit.INCH)>10){
        
            angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            rotSpeed = (angles.firstAngle - 0) * .05;
                                                //gain = .05
                                                
             if (move < 0) 
                rotSpeed *= -1;
                
            frontleft.setPower(speed-rotSpeed);
            backleft.setPower(speed-rotSpeed);
            frontright.setPower(speed+rotSpeed);
            backright.setPower(speed+rotSpeed);
            
            // if it starts spinning change symbols from + to -.  
            telemetry.addData("frontleft", frontleft.getCurrentPosition());
            telemetry.addData("backleft", backleft.getCurrentPosition());
            telemetry.addData("frontright", frontright.getCurrentPosition());
            telemetry.addData("backright", backright.getCurrentPosition());
            telemetry.addData("heading", angles.firstAngle);
            telemetry.addData("range", String.format("%.01f in", sensorRange.getDistance(DistanceUnit.INCH)));
            telemetry.update();
            //telemetry.addData("heading", angles.firstAngle);
            //telemetry.addData("rotspeed", rotSpeed);
            //telemetry.addData("speed", speed);
            //telemetry.addData("range", String.format("%.01f in", sensorRange.getDistance(DistanceUnit.INCH)));
            //telemetry.update();
            
            if (exit){
                frontright.setPower(0);
                frontleft.setPower(0);
                backright.setPower(0);
                backleft.setPower(0);
                return;
            }
        }
        frontright.setPower(0);
        frontleft.setPower(0);
        backright.setPower(0);
        backleft.setPower(0);
        return;
    }
    
}
    
    
        
    //
