package org.firstinspires.ftc.teamcode;



import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.Light;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.hardware.bosch.BNO055IMU;
@TeleOp
public class MecanumTeleOp extends LinearOpMode {
   
   Servo   servo;
   
   BNO055IMU imu;
   
   Orientation angles;
   Acceleration gravity;
   
   @Override
   public void runOpMode() throws InterruptedException {
      // Declare our motors
      // Make sure your ID's match your configuration
      DcMotor motorFrontLeft = hardwareMap.dcMotor.get("left_front");
      DcMotor motorBackLeft = hardwareMap.dcMotor.get("left_back");
      DcMotor motorFrontRight = hardwareMap.dcMotor.get("right_front");
      DcMotor motorBackRight = hardwareMap.dcMotor.get("right_back");
      DcMotor Duckspinner = hardwareMap.dcMotor.get("Duckspinner");
      DcMotor Arm = hardwareMap.dcMotor.get("Arm");
      DcMotor Outtake = hardwareMap.dcMotor.get("Outtake");
     // DcMotor Light = hardwareMap.dcMotor.get("Light");
      servo = hardwareMap.get(Servo.class, "Claw");
      // Reverse the right side motors
      // Reverse left motors if you are using NeveRests
      motorFrontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
      motorBackLeft.setDirection(DcMotorSimple.Direction.REVERSE);

       // Arm.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        BNO055IMU imu;
        Orientation angles;

 BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.calibrationDataFile = "BNO055IMUCalibration.json"; // see the calibration sample opmode
        parameters.loggingEnabled      = true;
        parameters.loggingTag          = "IMU";
        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();

        imu = hardwareMap.get(BNO055IMU.class,  "imu");
       // BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();

      waitForStart();

      

       imu.startAccelerationIntegration(new Position(), new Velocity(), 1000);  
      
      if (isStopRequested()) return;
        double duckSpinnerSpeed = 0;
        double ClawPosition = 1;
        double duckSpinnerMax;
        int ArmPosition = Arm.getCurrentPosition();
        double ArmPower;
      while (opModeIsActive()) {
         double y = -gamepad1.left_stick_y; // Remember, this is reversed!
         double x = gamepad1.left_stick_x * 1.1; // Counteract imperfect strafing
         double rx = gamepad1.right_stick_x;
       // Light.setPower(.5);
         // Denominator is the largest motor power (absolute value) or 1
         // This ensures all the powers maintain the same ratio, but only when
         // at least one is out of the range [-1, 1]
         double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
         double frontLeftPower = ((y + x + rx) / denominator)*((y + x + rx) / denominator)*((y + x + rx) / denominator);
         double backLeftPower = ((y - x + rx) / denominator)*((y - x + rx) / denominator)*((y - x + rx) / denominator);
         double frontRightPower = ((y - x - rx) / denominator)*((y - x - rx) / denominator)*((y - x - rx) / denominator);
         double backRightPower = ((y + x - rx) / denominator)*((y + x - rx) / denominator)*((y + x - rx) / denominator);
        
        
    
        motorFrontLeft.setPower(frontLeftPower);
        motorBackLeft.setPower(backLeftPower);
        motorFrontRight.setPower(frontRightPower);
        motorBackRight.setPower(backRightPower);
         
/*        if (gamepad1.right_trigger>.2)
            Duckspinner.setPower(-gamepad1.right_trigger);
         else if (gamepad1.left_trigger>.2)
          Duckspinner.setPower(1*gamepad1.left_trigger);
          else  
          Duckspinner.setPower(0);
  */        
    
    Duckspinner.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        {
            duckSpinnerMax = 1;
            if (gamepad1.right_trigger>.2)
            {    duckSpinnerSpeed += .1;
               if (duckSpinnerSpeed > duckSpinnerMax)
               duckSpinnerSpeed = duckSpinnerMax;
            }
            else if (gamepad1.left_trigger>.2)
            {duckSpinnerSpeed -= .1;
            if (duckSpinnerSpeed < -duckSpinnerMax)
               duckSpinnerSpeed = -duckSpinnerMax;
            }
            else 
            duckSpinnerSpeed = 0;
            
            Duckspinner.setPower(duckSpinnerSpeed);
        }
        
        /*  if (gamepad2.left_trigger>.2) 
            ClawPosition += .005;
        else if (gamepad2.right_trigger>.2)
            ClawPosition -= .005;
        if (ClawPosition < .5)
            ClawPosition = .5;
        if (ClawPosition > 1)
            ClawPosition = 1;
       
        servo.setPosition(ClawPosition);
        */
        //  telemetry.addData("ClawPosition", ClawPosition);
          //telemetry.update();
  
        if (gamepad2.left_bumper) {
        Outtake.setPower(1);
        }
        if (gamepad2.right_bumper) {
        Outtake.setPower(-1);
        }
        if (gamepad2.left_trigger > .2) {
        Outtake.setPower(.5);
        }
        else
        Outtake.setPower(0);
    
        if (gamepad2.a) {
            ArmPosition = -1300;
       
        }
        
        if (gamepad2.y) {
            ArmPosition = -1800;
       
        }
        
        if (gamepad2.x) {
            ArmPosition = -800;
       
        }
        
        if (gamepad2.b) {
            ArmPosition = -400;
       
        }
        if (gamepad2.dpad_down) {
            ArmPosition = -0;
       
        }
        ArmPower = 1;
        
       Arm.setTargetPosition(ArmPosition);
       Arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
       Arm.setPower(ArmPower);
     
     telemetry.addData("ArmPosition", ArmPosition);
     telemetry.addData("ArmPower", ArmPower);
     telemetry.update();
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        double yaw = -angles.firstAngle;
        telemetry.addData("Direction", yaw);
      }
   
       
   }
}



